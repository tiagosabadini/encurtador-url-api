import express, { Request, Response } from "express";
import cors from 'cors';
import firestore from './firestore';
import unidid from "uniqid";

const api = express();
api.use(express.json());
api.use(cors());


api.get('/listar', async (req: Request, res: Response) => {
  const querySnapshot = await firestore.collection("urls").get();
  const list: Array<any> = [];
  querySnapshot.forEach(doc => {
    list.push({
      "id": doc.id,
      "url": doc.data().url_original,
      "hash": doc.data().url_hash
    });
  });
  res.json(list);
});

api.post('/cadastrar', async (req: Request, res: Response) => {
  const {url} = req.body;
  const {id} = await firestore.collection("urls").add({
    "url_hash": unidid.time(),
    "url_original": url
  });
  const data = await firestore.collection("urls").doc(id).get();
  res.json(data.data());
});

api.put('/editar/:id', async (req: Request, res: Response) => {
  const {url} = req.body;
  await firestore.collection("urls").doc(req.params.id).update({
    "url_original": url
  });
  res.json({
    "success": true
  });
});

api.delete('/excluir/:id', async (req: Request, res: Response) => {
  await firestore.collection("urls").doc(req.params.id).delete();
  res.json({
    "success": true
  });
});




api.listen(1234, () => console.log('Server listening'));